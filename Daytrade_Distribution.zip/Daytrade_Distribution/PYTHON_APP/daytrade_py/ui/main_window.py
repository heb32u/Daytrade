import secrets
from datetime import datetime, timezone

import pandas as pd
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QMessageBox, QInputDialog
)

from core.exchanges import EXCHANGES, detect_exchange
from core.models import SessionRules, IndicatorConfig
from core.sessions import get_session_status
from core.indicators import compute_pack, bias_from_ema_di
from core.optimizer import optimize_one_year

from core.approvals import create_approval, verify
from core.autoexec import AutoExecPolicy, AutoExecutor, utcnow, iso

from core.paper_trading import PaperExecution, AlpacaPaperExecution, OrderRequest

from data.broker_sources import AlpacaBroker, IbkrBroker

from storage.repositories import SettingsRepo, CandleRepo, ApprovalRepo, OptimizerRepo
from storage.paper_repo import PaperRepo

from ui.chart_widget import ChartWidget
from ui.banner_widget import BannerWidget
from ui.settings_dialog import SettingsDialog
from ui.approvals_dialog import ApprovalsDialog
from ui.import_dialog import ImportDialog
from ui.positions_widget import PositionsWidget
from ui.pending_intents_widget import PendingIntentsWidget


class MainWindow(QMainWindow):
    def __init__(self, con):
        super().__init__()
        self.setWindowTitle("DayTradeApp (Python)")

        self.con = con
        self.settings = SettingsRepo(con)
        self.candles = CandleRepo(con)
        self.approvals = ApprovalRepo(con)
        self.opt = OptimizerRepo(con)
        self.paper_repo = PaperRepo(con)

        # Defaults
        if self.settings.get("universe") is None:
            self.settings.set("universe", "SPY,AAPL,TSLA")
        if self.settings.get("exchange_default") is None:
            self.settings.set("exchange_default", "NYSE")
        if self.settings.get("data_source") is None:
            self.settings.set("data_source", "CSV")
        if self.settings.get("asset_type") is None:
            self.settings.set("asset_type", "stocks")
        if self.settings.get("trade_mode") is None:
            self.settings.set("trade_mode", "PAPER_SIM")
        if self.settings.get("pending_intents") is None:
            self.settings.set_json("pending_intents", [])
        if self.settings.get("autoexec") is None:
            self.settings.set_json(
                "autoexec",
                {
                    "enabled": False,
                    "min_confidence": 0.70,
                    "bias_buy": 0.20,
                    "bias_sell": -0.20,
                    "cooldown_minutes": 15,
                    "max_trades_per_day": 6,
                    "max_position_abs": 5.0,
                    "require_session_open": True,
                    "require_approval_per_incident": True,
                    "approval_resend_minutes": 5,
                    "equity_assumed": 100000.0,
                    "risk_pct": 0.002,
                    "atr_stop_mult": 1.5,
                    "min_qty": 1.0,
                    "max_qty": 5.0,
                },
            )

        cfg = self.settings.get_json("autoexec", {})
        self.autoexec = AutoExecutor(AutoExecPolicy(**cfg))

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        top = QHBoxLayout()
        top.addWidget(QLabel("Symbol:"))
        self.symbol_box = QComboBox()
        top.addWidget(self.symbol_box)

        btn_import = QPushButton("Import CSV")
        btn_import.clicked.connect(self.import_csv)
        btn_settings = QPushButton("Settings")
        btn_settings.clicked.connect(self.open_settings)
        btn_approvals = QPushButton("Approvals")
        btn_approvals.clicked.connect(self.open_approvals)
        btn_opt = QPushButton("Optimize (1y)")
        btn_opt.clicked.connect(self.optimize_current)

        btn_load_1y = QPushButton("Load 1y (broker)")
        btn_load_1y.clicked.connect(self.load_one_year_from_broker)

        btn_pbuy = QPushButton("Paper Buy 1 (req approval)")
        btn_pbuy.clicked.connect(self.paper_buy_1)
        btn_psell = QPushButton("Paper Sell 1 (req approval)")
        btn_psell.clicked.connect(self.paper_sell_1)

        btn_exec_approved = QPushButton("Execute Approved Trade")
        btn_exec_approved.clicked.connect(self.execute_approved_trade)

        self.btn_arm = QPushButton("AutoExec: DISARMED")
        self.btn_arm.clicked.connect(self.toggle_autoexec)

        top.addWidget(btn_import)
        top.addWidget(btn_settings)
        top.addWidget(btn_approvals)
        top.addWidget(btn_opt)
        top.addWidget(btn_load_1y)
        top.addWidget(btn_pbuy)
        top.addWidget(btn_psell)
        top.addWidget(btn_exec_approved)
        top.addWidget(self.btn_arm)
        root.addLayout(top)

        self.chart = ChartWidget()
        root.addWidget(self.chart)

        self.status = QLabel("—")
        root.addWidget(self.status)

        self.pending_label = QLabel("Pending intents: 0")
        root.addWidget(self.pending_label)

        self.banner = BannerWidget()
        root.addWidget(self.banner)

        self.positions_widget = PositionsWidget()
        root.addWidget(self.positions_widget)

        self.pending_widget = PendingIntentsWidget(
            on_cancel_selected=self.cancel_intent_by_id,
            on_cancel_all=self.cancel_all_intents,
            on_execute_selected=self.execute_intent_auto_match,
            on_open_approvals=self.open_approvals,
        )
        root.addWidget(self.pending_widget)

        self.reload_universe()
        self.symbol_box.currentTextChanged.connect(self.refresh_now)

        self.banner_timer = QTimer(self)
        self.banner_timer.setInterval(1000)
        self.banner_timer.timeout.connect(self.refresh_banner_only)
        self.banner_timer.start()

        self.pending_timer = QTimer(self)
        self.pending_timer.setInterval(1000)
        self.pending_timer.timeout.connect(self.refresh_pending_table)
        self.pending_timer.start()

        self.engine_timer = QTimer(self)
        self.engine_timer.setInterval(5 * 60 * 1000)
        self.engine_timer.timeout.connect(self.refresh_now)
        self.engine_timer.start()

        self._sync_autoexec_button()
        self.refresh_now()
        self.refresh_pending_table()

    # ---------- Settings & Universe ----------
    def reload_universe(self):
        uni = self.settings.get("universe", "SPY,AAPL,TSLA")
        syms = [x.strip().upper() for x in uni.split(",") if x.strip()]
        self.symbol_box.clear()
        self.symbol_box.addItems(syms)

    def open_settings(self):
        dlg = SettingsDialog(self.settings)
        dlg.exec()
        self.reload_universe()
        self.autoexec.policy = AutoExecPolicy(**self.settings.get_json("autoexec", {}))
        self._sync_autoexec_button()
        self.refresh_now()

    def open_approvals(self):
        dlg = ApprovalsDialog(self.approvals)
        dlg.exec()
        self.refresh_pending_table()

    # ---------- CSV Import ----------
    def import_csv(self):
        dlg = ImportDialog()
        if dlg.exec() != dlg.Accepted or not dlg.csv_path:
            return
        df = pd.read_csv(dlg.csv_path)
        required = {"symbol", "ts_utc", "open", "high", "low", "close", "volume"}
        if not required.issubset(set(df.columns)):
            QMessageBox.warning(self, "CSV error", f"CSV must contain columns: {sorted(required)}")
            return
        df["symbol"] = df["symbol"].astype(str).str.upper()
        df = df.sort_values(["symbol", "ts_utc"])
        for sym, part in df.groupby("symbol"):
            rows = part[["ts_utc", "open", "high", "low", "close", "volume"]].to_dict("records")
            self.candles.upsert_many(sym, rows)
        QMessageBox.information(self, "Imported", f"Imported {len(df)} rows.")
        self.refresh_now()

    # ---------- Broker Data ----------
    def _get_broker(self):
        src = self.settings.get("data_source", "CSV").upper()
        if src == "ALPACA":
            return AlpacaBroker()
        if src == "IBKR":
            return IbkrBroker()
        return None

    def load_one_year_from_broker(self):
        symbol = self.symbol_box.currentText().strip().upper()
        broker = self._get_broker()
        if not broker:
            QMessageBox.information(self, "Broker", "Select ALPACA or IBKR in Settings.")
            return
        try:
            rows = broker.fetch_last_year_5m(symbol)
            if rows:
                self.candles.upsert_many(symbol, rows)
            QMessageBox.information(self, "Loaded", f"Loaded {len(rows)} candles for {symbol}.")
            self.refresh_now()
        except Exception as ex:
            QMessageBox.warning(self, "Broker error", str(ex))

    def ingest_latest_from_broker(self, symbol: str):
        src = self.settings.get("data_source", "CSV").upper()
        if src not in ("ALPACA", "IBKR"):
            return
        try:
            broker = self._get_broker()
            if not broker:
                return
            rows = broker.fetch_latest_5m(symbol)
            if rows:
                self.candles.upsert_many(symbol, rows)
        except Exception:
            return

    # ---------- Paper Execution ----------
    def _get_execution(self):
        mode = self.settings.get("trade_mode", "PAPER_SIM").upper()
        if mode == "ALPACA_PAPER":
            return AlpacaPaperExecution()
        if not hasattr(self, "_paper_exec"):
            self._paper_exec = PaperExecution(self.paper_repo)
        return self._paper_exec

    def _refresh_positions_panel(self):
        positions = self.paper_repo.load_positions()
        trades = self.paper_repo.load_trades(limit=200)
        self.positions_widget.set_positions(positions)
        self.positions_widget.set_trades(trades)

    # ---------- Approvals helpers ----------
    def request_trade_approval(self, symbol: str, side: str, qty: float, reason: str):
        try:
            a = create_approval(reason=reason, expires_days=3)
            self.approvals.create(a["approval_id"], a["token_hash"], reason, a["expires_utc"])
            QMessageBox.information(
                self,
                "Approval sent",
                f"Approval ID: {a['approval_id']}\nToken sent to Hugh.Bell@charter.net\n"
                f"Use Pending Intents → Execute Approved (auto-match).",
            )
            return a["approval_id"]
        except Exception as ex:
            QMessageBox.warning(self, "Approval email failed", f"Email failed; trade blocked.\n{ex}")
            return None

    # ---------- Pending intents persistence ----------
    def _pending_intents(self):
        return self.settings.get_json("pending_intents", [])

    def _save_pending_intents(self, intents):
        self.settings.set_json("pending_intents", intents)

    def _cancel_intent(self, intent, why: str):
        ap_id = intent.get("approval_id")
        if ap_id:
            self.approvals.reject(ap_id)
        intents = [x for x in self._pending_intents() if x.get("intent_id") != intent.get("intent_id")]
        self._save_pending_intents(intents)
        self.status.setText(f"Intent cancelled: {why}")

    def cancel_intent_by_id(self, intent_id: str):
        intents = self._pending_intents()
        target = next((it for it in intents if it.get("intent_id") == intent_id), None)
        if not target:
            QMessageBox.information(self, "Pending intents", "Intent not found.")
            return
        self._cancel_intent(target, "manual cancel")
        self.refresh_pending_table()

    def cancel_all_intents(self):
        intents = list(self._pending_intents())
        for it in intents:
            self._cancel_intent(it, "manual cancel all")
        self.refresh_pending_table()

    def refresh_pending_table(self):
        intents = sorted(self._pending_intents(), key=lambda x: x.get("created_utc", ""), reverse=True)
        self.pending_widget.set_intents(intents)
        self.pending_label.setText(f"Pending intents: {len(intents)}")

    # ---------- Execute Approved (auto-match) ----------
    def execute_intent_auto_match(self, intent_id: str):
        intents = self._pending_intents()
        intent = next((it for it in intents if it.get("intent_id") == intent_id), None)
        if not intent:
            QMessageBox.information(self, "Execute", "Intent not found.")
            return

        approval_id = intent.get("approval_id")
        if not approval_id:
            QMessageBox.warning(self, "Execute", "Intent missing approval_id.")
            return

        token, ok = QInputDialog.getText(self, "Execute Approved (auto-match)", f"Token for approval {approval_id}:")
        if not ok or not token.strip():
            return

        row = self.approvals.get(approval_id)
        if not row:
            QMessageBox.warning(self, "Execute", "Approval not found in DB.")
            return

        ap_id, token_hash, status, expires_utc, _ = row
        if status != "PENDING":
            QMessageBox.warning(self, "Execute", f"Approval is {status}.")
            return

        from datetime import datetime, timezone
        exp = datetime.strptime(expires_utc, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > exp:
            QMessageBox.warning(self, "Execute", "Approval expired.")
            return
        if not verify(token.strip(), token_hash):
            QMessageBox.warning(self, "Execute", "Token invalid.")
            return

        if not self.approvals.consume(ap_id):
            QMessageBox.warning(self, "Execute", "Could not consume approval (already used?).")
            return

        symbol = intent["symbol"].upper()
        side = intent["side"].lower()
        qty = float(intent["qty"])
        reason = intent.get("reason", "")

        df = self.candles.load_df(symbol)
        if df.empty:
            QMessageBox.warning(self, "Execute", "No price data for symbol.")
            return
        fill_price = float(df.iloc[-1]["close"])

        execu = self._get_execution()
        try:
            if execu.__class__.__name__ == "AlpacaPaperExecution":
                res = execu.execute(OrderRequest(symbol=symbol, side=side, qty=qty, reason=reason))
                QMessageBox.information(self, "Executed", f"Submitted to Alpaca paper.\n{res}")
            else:
                res = execu.execute(OrderRequest(symbol=symbol, side=side, qty=qty, reason=reason), fill_price=fill_price)
                QMessageBox.information(self, "Executed", f"Paper simulated.\n{res}")
                self._refresh_positions_panel()

            self.autoexec.mark_traded(symbol)
            intents = [x for x in self._pending_intents() if x.get("intent_id") != intent_id]
            self._save_pending_intents(intents)
            self.refresh_pending_table()

        except Exception as ex:
            QMessageBox.warning(self, "Execute", str(ex))

    def execute_approved_trade(self):
        # generic dialog fallback
        approval_id, ok = QInputDialog.getText(self, "Execute Approved Trade", "Approval ID:")
        if not ok or not approval_id.strip():
            return
        token, ok = QInputDialog.getText(self, "Execute Approved Trade", "Token:")
        if not ok or not token.strip():
            return

        row = self.approvals.get(approval_id.strip())
        if not row:
            QMessageBox.warning(self, "Approval", "Approval not found.")
            return
        ap_id, token_hash, status, expires_utc, _ = row
        if status != "PENDING":
            QMessageBox.warning(self, "Approval", f"Approval is {status}.")
            return

        exp = datetime.strptime(expires_utc, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > exp:
            QMessageBox.warning(self, "Approval", "Approval expired.")
            return
        if not verify(token.strip(), token_hash):
            QMessageBox.warning(self, "Approval", "Token invalid.")
            return
        if not self.approvals.consume(ap_id):
            QMessageBox.warning(self, "Approval", "Could not consume approval.")
            return

        QMessageBox.information(self, "Consumed", "Approval consumed. Use Pending Intents Execute for auto-match.")

    # ---------- Manual trade requests ----------
    def paper_buy_1(self):
        symbol = self.symbol_box.currentText().strip().upper()
        reason = f"Manual paper request: BUY 1 {symbol}"
        approval_id = self.request_trade_approval(symbol, "buy", 1.0, reason)
        if approval_id:
            self._enqueue_manual_intent(symbol, "buy", 1.0, reason, approval_id)

    def paper_sell_1(self):
        symbol = self.symbol_box.currentText().strip().upper()
        reason = f"Manual paper request: SELL 1 {symbol}"
        approval_id = self.request_trade_approval(symbol, "sell", 1.0, reason)
        if approval_id:
            self._enqueue_manual_intent(symbol, "sell", 1.0, reason, approval_id)

    def _enqueue_manual_intent(self, symbol: str, side: str, qty: float, reason: str, approval_id: str):
        intents = self._pending_intents()
        intent_id = secrets.token_hex(12)
        intents.append({
            "intent_id": intent_id,
            "created_utc": iso(utcnow()),
            "symbol": symbol.upper(),
            "side": side,
            "qty": float(qty),
            "reason": reason,
            "approval_id": approval_id,
        })
        self._save_pending_intents(intents)
        self.refresh_pending_table()

    # ---------- AutoExec ----------
    def toggle_autoexec(self):
        cfg = self.settings.get_json("autoexec", {})
        cfg["enabled"] = not bool(cfg.get("enabled", False))
        self.settings.set_json("autoexec", cfg)
        self.autoexec.policy = AutoExecPolicy(**cfg)
        self._sync_autoexec_button()

    def _sync_autoexec_button(self):
        enabled = bool(self.settings.get_json("autoexec", {}).get("enabled", False))
        self.btn_arm.setText("AutoExec: ARMED" if enabled else "AutoExec: DISARMED")
        self.btn_arm.setStyleSheet(
            "font-weight: bold; "
            + ("background: #2E8B57; color: white;" if enabled else "background: #8B0000; color: white;")
        )

    def _queue_intent_if_needed(self, symbol: str, side: str, qty: float, reason: str):
        symbol = symbol.upper()
        intents = self._pending_intents()
        if any(it.get("symbol") == symbol for it in intents):
            return
        if not self.autoexec.should_send_approval(symbol):
            return
        approval_id = self.request_trade_approval(symbol, side, qty, reason)
        if not approval_id:
            return
        self.autoexec.mark_approval_sent(symbol)
        intent_id = secrets.token_hex(12)
        intents.append({
            "intent_id": intent_id,
            "created_utc": iso(utcnow()),
            "symbol": symbol,
            "side": side,
            "qty": float(qty),
            "reason": reason,
            "approval_id": approval_id,
        })
        self._save_pending_intents(intents)
        self.refresh_pending_table()

    # ---------- Refresh loop ----------
    def refresh_banner_only(self):
        self._update_banner(self.symbol_box.currentText().strip().upper())

    def refresh_now(self):
        symbol = self.symbol_box.currentText().strip().upper()
        if not symbol:
            return

        self.ingest_latest_from_broker(symbol)

        df = self.candles.load_df(symbol)
        if df.empty:
            self.status.setText("No candle data. Import CSV or Load 1y (broker).")
            self.banner.set_state("—", "No data", "#666666", False)
            self._refresh_positions_panel()
            self.refresh_pending_table()
            return

        df["ts_utc"] = pd.to_datetime(df["ts_utc"], utc=True)
        df = df.set_index("ts_utc")

        best = self.opt.get_best(symbol)
        cfg = IndicatorConfig()
        if best:
            cfg.ema_fast = int(best.get("ema_fast", cfg.ema_fast))
            cfg.ema_slow = int(best.get("ema_slow", cfg.ema_slow))
            cfg.rsi_period = int(best.get("rsi_period", cfg.rsi_period))
            cfg.macd_signal = int(best.get("macd_signal", cfg.macd_signal))

        pack = compute_pack(df[["open", "high", "low", "close", "volume"]], cfg).dropna()
        if pack.empty:
            self.status.setText("Not enough bars to compute indicators.")
            return

        last = pack.iloc[-1]
        bias = bias_from_ema_di(last)

        self.chart.set_series(pack["close"].values[-300:])
        # confidence derived from signal tags
        from core.signals import classify
        sig = classify(last)
        self.chart.set_border_from_bias(bias=bias, confidence=sig["confidence"])

        sess = self._update_banner(symbol)

        # Auto-cancel pending intent for this symbol if flip/session change
        intents = self._pending_intents()
        for it in list(intents):
            if it.get("symbol") == symbol:
                if self.autoexec.should_cancel_intent(last, bias, bool(sess.get("is_open", False))):
                    self._cancel_intent(it, "signal/session changed")

        # Auto decide & queue
        self.autoexec.policy = AutoExecPolicy(**self.settings.get_json("autoexec", {}))
        current_pos = float(self.paper_repo.load_positions().get(symbol, 0.0))
        intent = self.autoexec.decide_intent(
            symbol=symbol,
            pack_last_row=last,
            bias=bias,
            current_pos=current_pos,
            session_is_open=bool(sess.get("is_open", False)),
        )
        if intent:
            self._queue_intent_if_needed(symbol, intent["side"], intent["qty"], intent["reason"])

        tags = ", ".join(sig["tags"])
        self.status.setText(f"{symbol} • {sig['state']} • bias={bias:+.2f} • conf={sig['confidence']:.2f} • {tags}")

        self._refresh_positions_panel()
        self.refresh_pending_table()

    def _update_banner(self, symbol: str):
        default_ex = self.settings.get("exchange_default", "NYSE").upper()
        overrides = self.settings.get_json("exchange_overrides", {})
        ex_code = overrides.get(symbol, detect_exchange(symbol, default_ex))
        ex = EXCHANGES.get(ex_code, EXCHANGES["NYSE"])

        rules = SessionRules(
            timezone=ex.timezone,
            session_open=ex.open_time,
            session_close=ex.close_time,
            is_24x7=False,
            is_24x5=False,
            weekly_open_utc=None,
            weekly_close_utc=None,
            observe_holidays=True,
            holiday_calendar_id=ex.holiday_calendar_id,
            breaks=ex.breaks,
            warmup_minutes=10,
            cooldown_minutes=10,
        )

        now = datetime.now(timezone.utc)
        sess = get_session_status(rules, now)
        self.banner.set_state(
            left_text=f"{ex_code} • Equities",
            right_text=sess["text"],
            color_hex=ex.color_hex,
            is_open=bool(sess.get("is_open", False)),
        )
        return sess

    # ---------- Optimizer ----------
    def optimize_current(self):
        symbol = self.symbol_box.currentText().strip().upper()
        df = self.candles.load_df(symbol)
        if df.empty:
            QMessageBox.warning(self, "No data", "No candles loaded.")
            return

        df["ts_utc"] = pd.to_datetime(df["ts_utc"], utc=True)
        df = df.set_index("ts_utc")

        one_year_ago = pd.Timestamp.utcnow() - pd.Timedelta(days=365)
        df = df[df.index >= one_year_ago]

        best = optimize_one_year(df)
        if "ema_fast" in best:
            self.opt.set_best(symbol, best)
            QMessageBox.information(self, "Optimized", f"Best params for {symbol}:\n{best}")
        else:
            QMessageBox.warning(self, "Optimize", "Not enough data to optimize.")

        self.refresh_now()
