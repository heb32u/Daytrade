from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QListWidget, QMessageBox
from datetime import datetime, timezone
from core.approvals import verify


class ApprovalsDialog(QDialog):
    def __init__(self, approval_repo):
        super().__init__()
        self.setWindowTitle("Approvals")
        self.r = approval_repo

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Pending approvals:"))
        self.list = QListWidget()
        layout.addWidget(self.list)

        row = QHBoxLayout()
        self.token = QLineEdit()
        self.token.setPlaceholderText("Enter token")
        btn_approve = QPushButton("Approve (consume)")
        btn_reject = QPushButton("Reject")
        btn_approve.clicked.connect(self.approve)
        btn_reject.clicked.connect(self.reject)
        row.addWidget(self.token)
        row.addWidget(btn_approve)
        row.addWidget(btn_reject)
        layout.addLayout(row)

        btn_refresh = QPushButton("Refresh")
        btn_refresh.clicked.connect(self.refresh)
        layout.addWidget(btn_refresh)

        self.refresh()

    def refresh(self):
        self.list.clear()
        for approval_id, created, expires, reason in self.r.list_pending():
            self.list.addItem(f"{approval_id} | exp {expires} | {reason}")

    def approve(self):
        item = self.list.currentItem()
        if not item:
            QMessageBox.warning(self, "Select", "Select an approval.")
            return
        approval_id = item.text().split("|")[0].strip()
        token = self.token.text().strip()
        row = self.r.get(approval_id)
        if not row:
            QMessageBox.warning(self, "Missing", "Approval not found.")
            return
        _, token_hash, status, expires_utc, _ = row
        if status != "PENDING":
            QMessageBox.warning(self, "Used", "Approval is not pending.")
            return
        exp = datetime.strptime(expires_utc, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) > exp:
            QMessageBox.warning(self, "Expired", "Approval expired.")
            return
        if not verify(token, token_hash):
            QMessageBox.warning(self, "Invalid", "Token invalid.")
            return
        if self.r.consume(approval_id):
            QMessageBox.information(self, "Approved", "Approval consumed.")
        self.refresh()

    def reject(self):
        item = self.list.currentItem()
        if not item:
            return
        approval_id = item.text().split("|")[0].strip()
        self.r.reject(approval_id)
        self.refresh()
