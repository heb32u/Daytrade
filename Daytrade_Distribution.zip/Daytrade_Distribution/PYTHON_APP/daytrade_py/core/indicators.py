import numpy as np
import pandas as pd


def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False).mean()
    rs = gain / (loss.replace(0, np.nan))
    return 100 - (100 / (1 + rs))


def macd(close: pd.Series, fast=12, slow=26, signal=9):
    macd_line = ema(close, fast) - ema(close, slow)
    signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist


def bollinger(close: pd.Series, period=20, std=2.0):
    mid = close.rolling(period).mean()
    dev = close.rolling(period).std(ddof=0)
    upper = mid + std * dev
    lower = mid - std * dev
    return mid, upper, lower


def true_range(df: pd.DataFrame) -> pd.Series:
    h, l, c = df["high"], df["low"], df["close"]
    prev_c = c.shift(1)
    tr = pd.concat([(h - l), (h - prev_c).abs(), (l - prev_c).abs()], axis=1).max(axis=1)
    return tr


def atr(df: pd.DataFrame, period=14) -> pd.Series:
    return true_range(df).ewm(alpha=1 / period, adjust=False).mean()


def obv(df: pd.DataFrame) -> pd.Series:
    direction = np.sign(df["close"].diff()).fillna(0)
    return (direction * df["volume"]).cumsum()


def adx_di(df: pd.DataFrame, period=14):
    high, low = df["high"], df["low"]
    up_move = high.diff()
    down_move = -low.diff()

    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)

    tr = true_range(df)
    atr_s = tr.ewm(alpha=1 / period, adjust=False).mean()

    plus_di = 100 * pd.Series(plus_dm, index=df.index).ewm(alpha=1 / period, adjust=False).mean() / atr_s
    minus_di = 100 * pd.Series(minus_dm, index=df.index).ewm(alpha=1 / period, adjust=False).mean() / atr_s
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    adx = dx.ewm(alpha=1 / period, adjust=False).mean()
    return adx, plus_di, minus_di


def compute_pack(df: pd.DataFrame, cfg) -> pd.DataFrame:
    out = df.copy()
    out["ema_fast"] = ema(out["close"], cfg.ema_fast)
    out["ema_slow"] = ema(out["close"], cfg.ema_slow)
    out["rsi"] = rsi(out["close"], cfg.rsi_period)
    macd_line, sig, hist = macd(out["close"], cfg.macd_fast, cfg.macd_slow, cfg.macd_signal)
    out["macd"], out["macd_signal"], out["macd_hist"] = macd_line, sig, hist
    mid, up, low = bollinger(out["close"], cfg.bb_period, cfg.bb_std)
    out["bb_mid"], out["bb_upper"], out["bb_lower"] = mid, up, low
    out["atr"] = atr(out, cfg.atr_period)
    out["obv"] = obv(out)
    adx_v, di_p, di_m = adx_di(out, cfg.adx_period)
    out["adx"], out["di_plus"], out["di_minus"] = adx_v, di_p, di_m
    return out


def bias_from_ema_di(row) -> float:
    ema_bias = np.tanh((row["ema_fast"] - row["ema_slow"]) / (row["atr"] + 1e-9))
    di_bias = np.tanh((row["di_plus"] - row["di_minus"]) / 25.0)
    return float(0.6 * ema_bias + 0.4 * di_bias)
