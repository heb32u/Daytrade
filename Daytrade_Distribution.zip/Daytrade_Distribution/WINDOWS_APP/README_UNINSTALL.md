# DayTradeAppPy (Windows) — Uninstall

1) Delete the EXE/folder.
2) Delete `%LOCALAPPDATA%\DayTradeAppPy\`
