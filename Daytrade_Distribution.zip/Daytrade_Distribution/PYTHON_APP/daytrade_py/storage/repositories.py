import json
import sqlite3
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Tuple

UTCNOW = lambda: datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class SettingsRepo:
    def __init__(self, con: sqlite3.Connection):
        self.con = con

    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        cur = self.con.execute("SELECT value FROM settings_kv WHERE key=?", (key,))
        row = cur.fetchone()
        return row[0] if row else default

    def set(self, key: str, value: str) -> None:
        self.con.execute(
            "INSERT INTO settings_kv(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        self.con.commit()

    def get_json(self, key: str, default):
        raw = self.get(key)
        if raw is None:
            return default
        try:
            return json.loads(raw)
        except Exception:
            return default

    def set_json(self, key: str, obj) -> None:
        self.set(key, json.dumps(obj))


class CandleRepo:
    def __init__(self, con: sqlite3.Connection):
        self.con = con

    def upsert_many(self, symbol: str, rows: List[Dict[str, Any]]):
        self.con.executemany(
            "INSERT INTO candles_5m(symbol,ts_utc,open,high,low,close,volume) "
            "VALUES(?,?,?,?,?,?,?) "
            "ON CONFLICT(symbol,ts_utc) DO UPDATE SET "
            "open=excluded.open, high=excluded.high, low=excluded.low, "
            "close=excluded.close, volume=excluded.volume",
            [
                (
                    symbol.upper(),
                    r["ts_utc"],
                    r["open"],
                    r["high"],
                    r["low"],
                    r["close"],
                    r["volume"],
                )
                for r in rows
            ],
        )
        self.con.commit()

    def load_df(self, symbol: str):
        import pandas as pd

        return pd.read_sql_query(
            "SELECT ts_utc, open, high, low, close, volume FROM candles_5m WHERE symbol=? ORDER BY ts_utc",
            self.con,
            params=(symbol.upper(),),
        )


class ApprovalRepo:
    def __init__(self, con: sqlite3.Connection):
        self.con = con

    def create(self, approval_id: str, token_hash: str, reason: str, expires_utc: str):
        now = UTCNOW()
        self.con.execute(
            "INSERT INTO approvals(approval_id,token_hash,status,created_utc,expires_utc,reason) "
            "VALUES(?,?,?,?,?,?)",
            (approval_id, token_hash, "PENDING", now, expires_utc, reason),
        )
        self.con.commit()

    def list_pending(self) -> List[Tuple]:
        cur = self.con.execute(
            "SELECT approval_id, created_utc, expires_utc, reason FROM approvals WHERE status='PENDING' ORDER BY created_utc DESC"
        )
        return cur.fetchall()

    def get(self, approval_id: str):
        cur = self.con.execute(
            "SELECT approval_id, token_hash, status, expires_utc, reason FROM approvals WHERE approval_id=?",
            (approval_id,),
        )
        return cur.fetchone()

    def consume(self, approval_id: str) -> bool:
        now = UTCNOW()
        cur = self.con.execute(
            "UPDATE approvals SET status='CONSUMED', consumed_utc=? WHERE approval_id=? AND status='PENDING'",
            (now, approval_id),
        )
        self.con.commit()
        return cur.rowcount == 1

    def reject(self, approval_id: str) -> bool:
        cur = self.con.execute(
            "UPDATE approvals SET status='REJECTED' WHERE approval_id=? AND status='PENDING'",
            (approval_id,),
        )
        self.con.commit()
        return cur.rowcount == 1


class OptimizerRepo:
    def __init__(self, con: sqlite3.Connection):
        self.con = con

    def set_best(self, symbol: str, params: Dict[str, Any]):
        self.con.execute(
            "INSERT INTO optimizer_best(symbol, params_json, updated_utc) VALUES(?,?,?) "
            "ON CONFLICT(symbol) DO UPDATE SET params_json=excluded.params_json, updated_utc=excluded.updated_utc",
            (symbol.upper(), json.dumps(params), UTCNOW()),
        )
        self.con.commit()

    def get_best(self, symbol: str) -> Optional[Dict[str, Any]]:
        cur = self.con.execute("SELECT params_json FROM optimizer_best WHERE symbol=?", (symbol.upper(),))
        row = cur.fetchone()
        return json.loads(row[0]) if row else None
