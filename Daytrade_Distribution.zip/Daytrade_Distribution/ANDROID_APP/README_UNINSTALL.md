# Android — Uninstall

Uninstall from device settings.
