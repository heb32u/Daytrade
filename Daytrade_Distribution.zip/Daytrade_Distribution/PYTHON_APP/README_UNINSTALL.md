# DayTradeAppPy (Python) — Uninstall

1) Delete `PYTHON_APP/daytrade_py`
2) Delete local DB folder:
   - Windows: `%LOCALAPPDATA%\DayTradeAppPy\`
   - macOS/Linux: `~/DayTradeAppPy/` (if you used home dir)
3) Delete `.venv` if present.
