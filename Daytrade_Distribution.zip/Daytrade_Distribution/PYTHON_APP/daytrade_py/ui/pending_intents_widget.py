from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QMessageBox
)
from PySide6.QtCore import Qt


class PendingIntentsWidget(QWidget):
    def __init__(self, on_cancel_selected, on_cancel_all, on_execute_selected, on_open_approvals):
        super().__init__()
        self._on_cancel_selected = on_cancel_selected
        self._on_cancel_all = on_cancel_all
        self._on_execute_selected = on_execute_selected
        self._on_open_approvals = on_open_approvals

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Pending Intents (approval-gated)"))

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Created (UTC)", "Symbol", "Side", "Qty", "Approval ID", "Reason"])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)

        btn_row = QHBoxLayout()

        self.btn_exec = QPushButton("Execute Approved (auto-match)")
        self.btn_exec.clicked.connect(self.execute_selected)

        self.btn_copy_approval = QPushButton("Copy Approval ID")
        self.btn_copy_approval.clicked.connect(self.copy_approval_id)

        self.btn_open_approvals = QPushButton("Open Approvals")
        self.btn_open_approvals.clicked.connect(self.open_approvals)

        self.btn_cancel = QPushButton("Cancel Selected")
        self.btn_cancel.clicked.connect(self.cancel_selected)

        self.btn_cancel_all = QPushButton("Cancel All")
        self.btn_cancel_all.clicked.connect(self.cancel_all)

        btn_row.addWidget(self.btn_exec)
        btn_row.addWidget(self.btn_copy_approval)
        btn_row.addWidget(self.btn_open_approvals)
        btn_row.addWidget(self.btn_cancel)
        btn_row.addWidget(self.btn_cancel_all)
        btn_row.addStretch(1)

        layout.addLayout(btn_row)

    def set_intents(self, intents: list[dict]):
        self.table.setRowCount(len(intents))
        for i, it in enumerate(intents):
            self._set(i, 0, it.get("created_utc", ""))
            self._set(i, 1, it.get("symbol", ""))
            self._set(i, 2, it.get("side", ""))
            self._set(i, 3, str(it.get("qty", "")))
            self._set(i, 4, it.get("approval_id", ""))
            self._set(i, 5, it.get("reason", ""))

        for i, it in enumerate(intents):
            vh = QTableWidgetItem(it.get("intent_id", ""))
            self.table.setVerticalHeaderItem(i, vh)

    def execute_selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Pending intents", "Select a row to execute.")
            return
        intent_id = self.table.verticalHeaderItem(row).text()
        if not intent_id:
            QMessageBox.warning(self, "Pending intents", "No intent_id for selected row.")
            return
        self._on_execute_selected(intent_id)

    def copy_approval_id(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Pending intents", "Select a row first.")
            return
        approval_id = self.table.item(row, 4).text().strip()
        if not approval_id:
            QMessageBox.warning(self, "Pending intents", "No approval id on selected row.")
            return
        from PySide6.QtGui import QGuiApplication
        QGuiApplication.clipboard().setText(approval_id)
        QMessageBox.information(self, "Copied", f"Copied approval id:\n{approval_id}")

    def open_approvals(self):
        self._on_open_approvals()

    def cancel_selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "Pending intents", "Select a row to cancel.")
            return
        intent_id = self.table.verticalHeaderItem(row).text()
        if not intent_id:
            QMessageBox.warning(self, "Pending intents", "No intent_id for selected row.")
            return
        self._on_cancel_selected(intent_id)

    def cancel_all(self):
        ok = QMessageBox.question(self, "Cancel all", "Cancel ALL pending intents?")
        if ok == QMessageBox.Yes:
            self._on_cancel_all()

    def _set(self, r, c, text):
        item = QTableWidgetItem(text)
        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        self.table.setItem(r, c, item)
