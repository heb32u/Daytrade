import os
from datetime import datetime, timedelta, timezone
from typing import List
import pandas as pd


class BrokerError(RuntimeError):
    pass


class AlpacaBroker:
    def __init__(self):
        try:
            from alpaca.data.historical import StockHistoricalDataClient
            from alpaca.data.requests import StockBarsRequest
            from alpaca.data.timeframe import TimeFrame
        except Exception as e:
            raise BrokerError("alpaca-py not installed. pip install alpaca-py") from e

        key = os.environ.get("ALPACA_API_KEY")
        secret = os.environ.get("ALPACA_API_SECRET")
        if not key or not secret:
            raise BrokerError("Missing ALPACA_API_KEY / ALPACA_API_SECRET")

        self.StockHistoricalDataClient = StockHistoricalDataClient
        self.StockBarsRequest = StockBarsRequest
        self.TimeFrame = TimeFrame
        self.client = StockHistoricalDataClient(key, secret)

    def fetch_last_year_5m(self, symbol: str):
        end = datetime.now(timezone.utc)
        start = end - timedelta(days=365)
        req = self.StockBarsRequest(
            symbol_or_symbols=symbol,
            timeframe=self.TimeFrame.Minute(5),
            start=start,
            end=end,
            adjustment="raw",
        )
        bars = self.client.get_stock_bars(req).df
        if bars is None or bars.empty:
            return []
        if isinstance(bars.index, pd.MultiIndex):
            bars = bars.xs(symbol, level=0, drop_level=True)
        bars = bars.reset_index().rename(columns={"timestamp": "ts"})
        bars["ts_utc"] = pd.to_datetime(bars["ts"], utc=True).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        return bars[["ts_utc", "open", "high", "low", "close", "volume"]].to_dict("records")

    def fetch_latest_5m(self, symbol: str):
        end = datetime.now(timezone.utc)
        start = end - timedelta(minutes=60)
        req = self.StockBarsRequest(
            symbol_or_symbols=symbol,
            timeframe=self.TimeFrame.Minute(5),
            start=start,
            end=end,
            adjustment="raw",
        )
        bars = self.client.get_stock_bars(req).df
        if bars is None or bars.empty:
            return []
        if isinstance(bars.index, pd.MultiIndex):
            bars = bars.xs(symbol, level=0, drop_level=True)
        bars = bars.reset_index().rename(columns={"timestamp": "ts"})
        bars["ts_utc"] = pd.to_datetime(bars["ts"], utc=True).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        tail = bars.tail(3)
        return tail[["ts_utc", "open", "high", "low", "close", "volume"]].to_dict("records")


class IbkrBroker:
    def __init__(self):
        try:
            from ib_insync import IB, Stock
        except Exception as e:
            raise BrokerError("ib_insync not installed. pip install ib_insync") from e

        host = os.environ.get("IBKR_HOST", "127.0.0.1")
        port = int(os.environ.get("IBKR_PORT", "7497"))
        client_id = int(os.environ.get("IBKR_CLIENT_ID", "7"))

        self.IB = IB
        self.Stock = Stock
        self.ib = IB()
        self.ib.connect(host, port, clientId=client_id)

    def fetch_last_year_5m(self, symbol: str, exchange="SMART", currency="USD"):
        contract = self.Stock(symbol, exchange, currency)
        self.ib.qualifyContracts(contract)
        bars = self.ib.reqHistoricalData(
            contract,
            endDateTime="",
            durationStr="1 Y",
            barSizeSetting="5 mins",
            whatToShow="TRADES",
            useRTH=False,
            formatDate=1,
        )
        out = []
        for b in bars or []:
            dt = b.date
            if not isinstance(dt, datetime):
                continue
            dt_utc = dt.astimezone(timezone.utc)
            out.append({
                "ts_utc": dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "open": float(b.open),
                "high": float(b.high),
                "low": float(b.low),
                "close": float(b.close),
                "volume": float(getattr(b, "volume", 0.0) or 0.0),
            })
        return out

    def fetch_latest_5m(self, symbol: str, exchange="SMART", currency="USD"):
        contract = self.Stock(symbol, exchange, currency)
        self.ib.qualifyContracts(contract)
        bars = self.ib.reqHistoricalData(
            contract,
            endDateTime="",
            durationStr="1 H",
            barSizeSetting="5 mins",
            whatToShow="TRADES",
            useRTH=False,
            formatDate=1,
        )
        bars = bars or []
        out = []
        for b in bars[-3:]:
            dt_utc = b.date.astimezone(timezone.utc)
            out.append({
                "ts_utc": dt_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "open": float(b.open),
                "high": float(b.high),
                "low": float(b.low),
                "close": float(b.close),
                "volume": float(getattr(b, "volume", 0.0) or 0.0),
            })
        return out
