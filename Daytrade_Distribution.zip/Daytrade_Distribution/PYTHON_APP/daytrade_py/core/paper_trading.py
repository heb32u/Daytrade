import os
from dataclasses import dataclass
from typing import Optional

from storage.paper_repo import PaperRepo


@dataclass
class OrderRequest:
    symbol: str
    side: str
    qty: float
    order_type: str = "market"
    tif: str = "day"
    limit_price: Optional[float] = None
    reason: str = ""


class ExecutionError(RuntimeError):
    pass


class PaperExecution:
    def __init__(self, paper_repo: PaperRepo):
        self.repo = paper_repo
        self.positions = self.repo.load_positions()
        self.trades = self.repo.load_trades(limit=200)

    def execute(self, req: OrderRequest, fill_price: float):
        sym = req.symbol.upper()
        qty = float(req.qty)
        if qty <= 0:
            raise ExecutionError("qty must be > 0")

        pos = float(self.positions.get(sym, 0.0))
        if req.side.lower() == "buy":
            pos += qty
        elif req.side.lower() == "sell":
            pos -= qty
        else:
            raise ExecutionError("side must be buy/sell")

        self.positions[sym] = pos
        self.repo.save_position(sym, pos)
        self.repo.insert_trade(sym, req.side, qty, float(fill_price), req.reason)
        self.trades = self.repo.load_trades(limit=200)

        return {"symbol": sym, "new_pos": pos}


class AlpacaPaperExecution:
    def __init__(self):
        try:
            from alpaca.trading.client import TradingClient
            from alpaca.trading.requests import MarketOrderRequest
            from alpaca.trading.enums import OrderSide, TimeInForce
        except Exception as e:
            raise ExecutionError("alpaca-py trading not available. pip install alpaca-py") from e

        key = os.environ.get("ALPACA_API_KEY")
        secret = os.environ.get("ALPACA_API_SECRET")
        if not key or not secret:
            raise ExecutionError("Missing ALPACA_API_KEY / ALPACA_API_SECRET")

        paper = os.environ.get("ALPACA_PAPER", "1").lower() in ("1", "true", "yes")
        if not paper:
            raise ExecutionError("Set ALPACA_PAPER=1 for paper trading mode.")

        self.client = TradingClient(key, secret, paper=True)
        self.MarketOrderRequest = MarketOrderRequest
        self.OrderSide = OrderSide
        self.TimeInForce = TimeInForce

    def execute(self, req: OrderRequest):
        side = self.OrderSide.BUY if req.side.lower() == "buy" else self.OrderSide.SELL
        order = self.MarketOrderRequest(
            symbol=req.symbol.upper(),
            qty=req.qty,
            side=side,
            time_in_force=self.TimeInForce.DAY,
        )
        return self.client.submit_order(order)
