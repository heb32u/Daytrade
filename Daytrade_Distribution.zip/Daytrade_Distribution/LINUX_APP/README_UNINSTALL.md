# DayTradeAppPy (Linux) — Uninstall

Delete the binary/folder and remove app data if created.
