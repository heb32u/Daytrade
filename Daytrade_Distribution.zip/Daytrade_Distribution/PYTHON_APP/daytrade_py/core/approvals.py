import os
import secrets
import ssl
import smtplib
import hashlib
from email.message import EmailMessage
from datetime import datetime, timedelta, timezone


def _utcnow():
    return datetime.now(timezone.utc)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def send_email(to_addr: str, subject: str, body: str):
    host = os.environ["SMTP_HOST"]
    port = int(os.environ.get("SMTP_PORT", "587"))
    user = os.environ["SMTP_USER"]
    pwd = os.environ["SMTP_PASS"]
    from_addr = os.environ.get("SMTP_FROM", user)

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = from_addr
    msg["To"] = to_addr
    msg.set_content(body)

    ctx = ssl.create_default_context()
    with smtplib.SMTP(host, port) as s:
        s.starttls(context=ctx)
        s.login(user, pwd)
        s.send_message(msg)


def create_approval(reason: str, expires_days: int = 3) -> dict:
    token = secrets.token_urlsafe(24)
    approval_id = secrets.token_hex(16)
    expires_at = _utcnow() + timedelta(days=expires_days)

    subject = "DayTradeApp Approval Required"
    body = (
        f"Approval ID: {approval_id}\n"
        f"Reason: {reason}\n"
        f"Token: {token}\n"
        f"Expires (UTC): {expires_at.strftime('%Y-%m-%dT%H:%M:%SZ')}\n"
    )

    send_email("Hugh.Bell@charter.net", subject, body)

    return {
        "approval_id": approval_id,
        "token": token,
        "token_hash": hash_token(token),
        "expires_utc": expires_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def verify(token: str, token_hash: str) -> bool:
    return hash_token(token) == token_hash
