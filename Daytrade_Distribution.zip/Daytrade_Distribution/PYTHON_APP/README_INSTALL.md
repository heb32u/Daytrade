# DayTradeAppPy (Python) — Install

## Prereqs
- Python 3.11+
- Optional brokers:
  - Alpaca: alpaca-py (ALPACA_API_KEY, ALPACA_API_SECRET, ALPACA_PAPER=1)
  - IBKR: ib_insync + TWS/IB Gateway running (IBKR_HOST, IBKR_PORT, IBKR_CLIENT_ID)
- SMTP required for approval emails (fail-safe blocks trades if missing):
  SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM

## Setup
1) Open terminal in `PYTHON_APP/daytrade_py`
2) Create venv:
   - Windows: `python -m venv .venv` then `.venv\Scripts\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
3) Install: `pip install -r requirements.txt`
4) Run: `python app.py`

## CSV format
Columns required:
`symbol, ts_utc, open, high, low, close, volume`
Example ts_utc: `2026-01-16T15:35:00Z`
