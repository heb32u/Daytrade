# DayTradeAppPy (Linux) — Install

Build using `LINUX_APP/build/pyinstaller_build.sh`.
Then run output in `LINUX_APP/dist`.
