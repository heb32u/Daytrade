from dataclasses import dataclass
from typing import Optional, List


@dataclass(frozen=True)
class MarketBreak:
    start: str
    end: str


@dataclass(frozen=True)
class Exchange:
    code: str
    name: str
    country: str
    timezone: str
    open_time: str
    close_time: str
    holiday_calendar_id: str
    color_hex: str
    breaks: List[MarketBreak]


@dataclass(frozen=True)
class SessionRules:
    timezone: str
    session_open: Optional[str]
    session_close: Optional[str]
    is_24x7: bool
    is_24x5: bool
    weekly_open_utc: Optional[str]
    weekly_close_utc: Optional[str]
    observe_holidays: bool
    holiday_calendar_id: Optional[str]
    breaks: List[MarketBreak]
    warmup_minutes: int = 0
    cooldown_minutes: int = 0


@dataclass
class IndicatorConfig:
    ema_fast: int = 12
    ema_slow: int = 26
    rsi_period: int = 14
    macd_fast: int = 12
    macd_slow: int = 26
    macd_signal: int = 9
    bb_period: int = 20
    bb_std: float = 2.0
    adx_period: int = 14
    atr_period: int = 14
