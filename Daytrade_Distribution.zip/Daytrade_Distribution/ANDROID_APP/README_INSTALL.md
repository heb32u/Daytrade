# Android — Placeholder

This folder is a scaffold placeholder. Build mobile packages with Briefcase (Python on mobile) or rewrite native.
