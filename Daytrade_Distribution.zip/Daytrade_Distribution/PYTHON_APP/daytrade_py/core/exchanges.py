from core.models import Exchange, MarketBreak

EXCHANGES = {
    "NYSE": Exchange("NYSE", "New York Stock Exchange", "USA", "America/New_York", "09:30", "16:00", "nyse", "#1E90FF", []),
    "NASDAQ": Exchange("NASDAQ", "Nasdaq Stock Market", "USA", "America/New_York", "09:30", "16:00", "nasdaq", "#4169E1", []),
    "LSE": Exchange("LSE", "London Stock Exchange", "UK", "Europe/London", "08:00", "16:30", "lse", "#2E8B57", []),
    "TSE": Exchange("TSE", "Tokyo Stock Exchange", "Japan", "Asia/Tokyo", "09:00", "15:00", "jpx", "#DC143C", [MarketBreak("11:30", "12:30")]),
    "SSE": Exchange("SSE", "Shanghai Stock Exchange", "China", "Asia/Shanghai", "09:30", "15:00", "sse", "#B22222", [MarketBreak("11:30", "13:00")]),
    "HKEX": Exchange("HKEX", "Hong Kong Stock Exchange", "Hong Kong", "Asia/Hong_Kong", "09:30", "16:00", "hkex", "#8B4513", [MarketBreak("12:00", "13:00")]),
    "EURONEXT": Exchange("EURONEXT", "Euronext", "Europe", "Europe/Paris", "09:00", "17:30", "euronext", "#6A5ACD", []),
    "BSE": Exchange("BSE", "Bombay Stock Exchange", "India", "Asia/Kolkata", "09:15", "15:30", "bse", "#FF8C00", []),
}


def detect_exchange(symbol: str, default_code: str = "NYSE") -> str:
    s = symbol.upper().strip()
    if s.endswith(".L"):
        return "LSE"
    if s.endswith(".T"):
        return "TSE"
    if s.endswith(".SS") or s.endswith(".SH"):
        return "SSE"
    if s.endswith(".HK"):
        return "HKEX"
    if s.endswith(".NS"):
        return "BSE"
    if s.endswith(".PA") or s.endswith(".AS") or s.endswith(".MI"):
        return "EURONEXT"
    return default_code if default_code in EXCHANGES else "NYSE"
