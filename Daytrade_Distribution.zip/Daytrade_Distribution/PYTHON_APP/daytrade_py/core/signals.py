
def classify(row) -> dict:
    trend_up = row["ema_fast"] > row["ema_slow"]
    trend_dn = row["ema_fast"] < row["ema_slow"]
    strong_trend = row["adx"] > 25

    rsi_os = row["rsi"] < 30
    rsi_ob = row["rsi"] > 70
    macd_up = row["macd"] > row["macd_signal"]
    macd_dn = row["macd"] < row["macd_signal"]

    bb_buy = row["close"] < row["bb_lower"]
    bb_sell = row["close"] > row["bb_upper"]

    score = 0
    tags = []

    if trend_up:
        score += 2
        tags.append("Trend↑")
    if trend_dn:
        score -= 2
        tags.append("Trend↓")
    if strong_trend:
        score += 1 if trend_up else (-1 if trend_dn else 0)
        tags.append("ADX>25")

    if macd_up:
        score += 1
        tags.append("MACD↑")
    if macd_dn:
        score -= 1
        tags.append("MACD↓")
    if rsi_os:
        score += 1
        tags.append("RSI<30")
    if rsi_ob:
        score -= 1
        tags.append("RSI>70")
    if bb_buy:
        score += 1
        tags.append("BB lower")
    if bb_sell:
        score -= 1
        tags.append("BB upper")

    if score >= 3:
        state = "BULLISH"
    elif score <= -3:
        state = "BEARISH"
    else:
        state = "NEUTRAL"

    confidence = min(1.0, abs(score) / 5.0)
    return {"state": state, "score": score, "confidence": confidence, "tags": tags}
