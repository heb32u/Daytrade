# iOS — Uninstall

Delete app from device.
