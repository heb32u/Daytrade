import json
import os
from datetime import datetime, timedelta, time
import pytz
from core.models import SessionRules


def _parse_hhmm(s: str) -> time:
    hh, mm = s.split(":")
    return time(int(hh), int(mm))


def _holiday_set(calendar_id: str) -> set[str]:
    path = os.path.join(os.path.dirname(__file__), "..", "assets", "holidays", f"holidays_{calendar_id}.json")
    path = os.path.abspath(path)
    if not os.path.exists(path):
        return set()
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return set(data.get("holidays", []))


def _is_holiday(rules: SessionRules, now_utc: datetime) -> bool:
    if not rules.observe_holidays or not rules.holiday_calendar_id:
        return False
    holidays = _holiday_set(rules.holiday_calendar_id)
    tz = pytz.timezone(rules.timezone)
    local = now_utc.astimezone(tz)
    return local.strftime("%Y-%m-%d") in holidays


def fmt(td: timedelta) -> str:
    secs = int(max(0, td.total_seconds()))
    h = secs // 3600
    m = (secs % 3600) // 60
    s = secs % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def get_session_status(rules: SessionRules, now_utc: datetime) -> dict:
    if rules.is_24x7:
        return {"is_open": True, "text": "Open • 24/7"}

    if _is_holiday(rules, now_utc):
        return {"is_open": False, "text": f"Closed • Holiday ({rules.holiday_calendar_id})"}

    tz = pytz.timezone(rules.timezone)
    local = now_utc.astimezone(tz)
    t = local.time()

    if rules.session_open and rules.session_close:
        o = _parse_hhmm(rules.session_open)
        c = _parse_hhmm(rules.session_close)
        is_open = (t >= o and t <= c)

        if is_open:
            for br in rules.breaks or []:
                bs, be = _parse_hhmm(br.start), _parse_hhmm(br.end)
                if t >= bs and t < be:
                    resume = datetime.combine(local.date(), be).replace(tzinfo=tz) - local
                    return {"is_open": True, "text": f"Break • resumes in {fmt(resume)}"}

            close_dt = datetime.combine(local.date(), c).replace(tzinfo=tz)
            left = close_dt - local
            return {"is_open": True, "text": f"Open • {fmt(left)} left"}

        open_dt = datetime.combine(local.date(), o).replace(tzinfo=tz)
        if t > c:
            open_dt = open_dt + timedelta(days=1)
        until = open_dt - local
        return {"is_open": False, "text": f"Closed • Opens in {fmt(until)}"}

    return {"is_open": True, "text": "Open"}
