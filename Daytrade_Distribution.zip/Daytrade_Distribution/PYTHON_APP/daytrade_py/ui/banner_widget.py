from PySide6.QtWidgets import QWidget, QHBoxLayout, QLabel
from PySide6.QtGui import QColor, QPalette


class BannerWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.left = QLabel("—")
        self.right = QLabel("—")
        self.right.setStyleSheet("font-family: Consolas;")

        layout = QHBoxLayout(self)
        layout.addWidget(self.left)
        layout.addStretch(1)
        layout.addWidget(self.right)

        self.setAutoFillBackground(True)

    def set_state(self, left_text: str, right_text: str, color_hex: str, is_open: bool):
        self.left.setText(left_text)
        self.right.setText(right_text)

        c = QColor(color_hex)
        pal = self.palette()
        pal.setColor(QPalette.Window, c)
        pal.setColor(QPalette.WindowText, QColor("#FFFFFF" if is_open else "#DDDDDD"))
        self.setPalette(pal)
        self.left.setPalette(pal)
        self.right.setPalette(pal)
