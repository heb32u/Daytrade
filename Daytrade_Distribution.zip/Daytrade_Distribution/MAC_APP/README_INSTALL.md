# DayTradeAppPy (macOS) — Install

Build using `MAC_APP/build/pyinstaller_build.sh`.
Then run output in `MAC_APP/dist`.
