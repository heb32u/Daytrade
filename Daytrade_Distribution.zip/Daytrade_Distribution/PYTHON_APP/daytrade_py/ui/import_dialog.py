from PySide6.QtWidgets import QDialog, QVBoxLayout, QPushButton, QFileDialog, QLabel


class ImportDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Import CSV (5m candles)")
        self.csv_path = None

        layout = QVBoxLayout(self)
        self.label = QLabel("Choose a CSV with columns: symbol, ts_utc, open, high, low, close, volume")
        layout.addWidget(self.label)

        btn = QPushButton("Select CSV…")
        btn.clicked.connect(self.pick)
        layout.addWidget(btn)

        ok = QPushButton("OK")
        ok.clicked.connect(self.accept)
        layout.addWidget(ok)

    def pick(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select CSV", "", "CSV Files (*.csv)")
        if path:
            self.csv_path = path
            self.label.setText(f"Selected: {path}")
