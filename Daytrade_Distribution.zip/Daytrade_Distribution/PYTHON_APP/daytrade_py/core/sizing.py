
def atr_position_size(
    equity: float,
    risk_pct: float,
    atr: float,
    atr_mult_stop: float = 1.5,
    min_qty: float = 1.0,
    max_qty: float = 5.0,
) -> float:
    equity = float(equity)
    risk_pct = float(risk_pct)
    atr = float(atr)

    if equity <= 0 or risk_pct <= 0 or atr <= 0:
        return float(min_qty)

    risk_dollars = equity * risk_pct
    denom = atr * float(atr_mult_stop)
    if denom <= 0:
        return float(min_qty)

    qty = risk_dollars / denom
    qty = max(min_qty, min(max_qty, qty))
    return float(qty)
