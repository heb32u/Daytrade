# DayTradeAppPy (Windows) — Install

## Build EXE
Run `WINDOWS_APP/build/pyinstaller_build.ps1` from PowerShell.

## Use
- Run `WINDOWS_APP/dist/DayTradeAppPy.exe`
- Configure SMTP env vars for approvals.
