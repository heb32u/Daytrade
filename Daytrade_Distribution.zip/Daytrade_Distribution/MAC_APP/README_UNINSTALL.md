# DayTradeAppPy (macOS) — Uninstall

Delete the app/binary and remove app data if created.
