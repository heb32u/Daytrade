import os
from PySide6.QtWidgets import QApplication
from storage.db import open_db


def main():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    db_path = os.path.join(base, "DayTradeAppPy", "daytrade.db")

    con = open_db(db_path)

    with open(os.path.join(os.path.dirname(__file__), "storage", "schema.sql"), "r", encoding="utf-8") as f:
        con.executescript(f.read())
        con.commit()

    from ui.main_window import MainWindow

    app = QApplication([])
    w = MainWindow(con)
    w.resize(1200, 820)
    w.show()
    app.exec()


if __name__ == "__main__":
    main()
