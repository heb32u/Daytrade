from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem


class PositionsWidget(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Paper Positions / Trades"))

        self.pos_table = QTableWidget(0, 2)
        self.pos_table.setHorizontalHeaderLabels(["Symbol", "Qty"])
        layout.addWidget(self.pos_table)

        self.trades_table = QTableWidget(0, 5)
        self.trades_table.setHorizontalHeaderLabels(["Time(UTC)", "Symbol", "Side", "Qty", "Fill"])
        layout.addWidget(self.trades_table)

    def set_positions(self, positions: dict):
        items = sorted(positions.items(), key=lambda kv: kv[0])
        self.pos_table.setRowCount(len(items))
        for i, (sym, qty) in enumerate(items):
            self.pos_table.setItem(i, 0, QTableWidgetItem(str(sym)))
            self.pos_table.setItem(i, 1, QTableWidgetItem(f"{float(qty):.4f}"))

    def set_trades(self, trades: list):
        tail = trades[-200:]
        self.trades_table.setRowCount(len(tail))
        for i, t in enumerate(tail):
            self.trades_table.setItem(i, 0, QTableWidgetItem(str(t.get("ts_utc", ""))))
            self.trades_table.setItem(i, 1, QTableWidgetItem(str(t.get("symbol", ""))))
            self.trades_table.setItem(i, 2, QTableWidgetItem(str(t.get("side", ""))))
            self.trades_table.setItem(i, 3, QTableWidgetItem(str(t.get("qty", ""))))
            self.trades_table.setItem(i, 4, QTableWidgetItem(str(t.get("fill_price", ""))))
