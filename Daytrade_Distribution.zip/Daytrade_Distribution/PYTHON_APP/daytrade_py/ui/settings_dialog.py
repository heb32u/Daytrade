from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QComboBox, QListWidget, QMessageBox
)
from core.exchanges import EXCHANGES


class SettingsDialog(QDialog):
    def __init__(self, settings_repo):
        super().__init__()
        self.setWindowTitle("Settings")
        self.s = settings_repo

        layout = QVBoxLayout(self)

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Data source:"))
        self.data_source = QComboBox()
        self.data_source.addItems(["CSV", "ALPACA", "IBKR"])
        row1.addWidget(self.data_source)
        layout.addLayout(row1)

        row_tm = QHBoxLayout()
        row_tm.addWidget(QLabel("Trade mode:"))
        self.trade_mode = QComboBox()
        self.trade_mode.addItems(["PAPER_SIM", "ALPACA_PAPER"])
        row_tm.addWidget(self.trade_mode)
        layout.addLayout(row_tm)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Asset type:"))
        self.asset_type = QComboBox()
        self.asset_type.addItems(["stocks", "crypto", "futures"])
        row2.addWidget(self.asset_type)
        layout.addLayout(row2)

        row3 = QHBoxLayout()
        row3.addWidget(QLabel("Universe (comma-separated):"))
        self.universe = QLineEdit()
        row3.addWidget(self.universe)
        layout.addLayout(row3)

        row4 = QHBoxLayout()
        row4.addWidget(QLabel("Default exchange:"))
        self.default_exchange = QComboBox()
        self.default_exchange.addItems(sorted(EXCHANGES.keys()))
        row4.addWidget(self.default_exchange)
        layout.addLayout(row4)

        layout.addWidget(QLabel(
            "Broker config (environment variables):\n"
            "ALPACA: ALPACA_API_KEY, ALPACA_API_SECRET, ALPACA_PAPER=1\n"
            "IBKR: IBKR_HOST=127.0.0.1, IBKR_PORT=7497, IBKR_CLIENT_ID=7 (TWS/IB Gateway running)\n"
            "SMTP (approvals): SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM"
        ))

        layout.addWidget(QLabel("Exchange overrides (one per line): e.g. AAPL=NASDAQ"))
        self.overrides = QListWidget()
        layout.addWidget(self.overrides)

        add_row = QHBoxLayout()
        self.ov_symbol = QLineEdit(); self.ov_symbol.setPlaceholderText("Symbol")
        self.ov_ex = QComboBox(); self.ov_ex.addItems(sorted(EXCHANGES.keys()))
        btn_add = QPushButton("Add/Update")
        btn_add.clicked.connect(self.add_override)
        btn_del = QPushButton("Remove")
        btn_del.clicked.connect(self.del_override)
        add_row.addWidget(self.ov_symbol)
        add_row.addWidget(self.ov_ex)
        add_row.addWidget(btn_add)
        add_row.addWidget(btn_del)
        layout.addLayout(add_row)

        btn_save = QPushButton("Save")
        btn_save.clicked.connect(self.save)
        layout.addWidget(btn_save)

        self.load()

    def load(self):
        self.data_source.setCurrentText(self.s.get("data_source", "CSV"))
        self.trade_mode.setCurrentText(self.s.get("trade_mode", "PAPER_SIM"))
        self.asset_type.setCurrentText(self.s.get("asset_type", "stocks"))
        self.universe.setText(self.s.get("universe", "SPY,AAPL,TSLA"))
        self.default_exchange.setCurrentText(self.s.get("exchange_default", "NYSE"))

        self.overrides.clear()
        ovs = self.s.get_json("exchange_overrides", {})
        for k, v in sorted(ovs.items()):
            self.overrides.addItem(f"{k.upper()}={v.upper()}")

    def add_override(self):
        sym = self.ov_symbol.text().strip().upper()
        ex = self.ov_ex.currentText().strip().upper()
        if not sym:
            QMessageBox.warning(self, "Missing", "Symbol required.")
            return
        ovs = self.s.get_json("exchange_overrides", {})
        ovs[sym] = ex
        self.s.set_json("exchange_overrides", ovs)
        self.load()

    def del_override(self):
        item = self.overrides.currentItem()
        if not item:
            return
        sym = item.text().split("=")[0].strip().upper()
        ovs = self.s.get_json("exchange_overrides", {})
        if sym in ovs:
            del ovs[sym]
            self.s.set_json("exchange_overrides", ovs)
        self.load()

    def save(self):
        self.s.set("data_source", self.data_source.currentText())
        self.s.set("trade_mode", self.trade_mode.currentText())
        self.s.set("asset_type", self.asset_type.currentText())
        self.s.set("universe", self.universe.text().strip())
        self.s.set("exchange_default", self.default_exchange.currentText())
        QMessageBox.information(self, "Saved", "Settings saved.")
        self.accept()
