import sqlite3
import secrets
from datetime import datetime, timezone


def utcnow_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class PaperRepo:
    def __init__(self, con: sqlite3.Connection):
        self.con = con

    def load_positions(self) -> dict:
        cur = self.con.execute("SELECT symbol, qty FROM paper_positions")
        return {r[0]: float(r[1]) for r in cur.fetchall()}

    def save_position(self, symbol: str, qty: float):
        self.con.execute(
            "INSERT INTO paper_positions(symbol, qty, updated_utc) VALUES(?,?,?) "
            "ON CONFLICT(symbol) DO UPDATE SET qty=excluded.qty, updated_utc=excluded.updated_utc",
            (symbol.upper(), float(qty), utcnow_iso()),
        )
        self.con.commit()

    def insert_trade(self, symbol: str, side: str, qty: float, fill_price: float, reason: str):
        trade_id = secrets.token_hex(16)
        self.con.execute(
            "INSERT INTO paper_trades(trade_id, symbol, side, qty, fill_price, reason, ts_utc) VALUES(?,?,?,?,?,?,?)",
            (trade_id, symbol.upper(), side.lower(), float(qty), float(fill_price), reason, utcnow_iso()),
        )
        self.con.commit()
        return trade_id

    def load_trades(self, limit: int = 200) -> list:
        cur = self.con.execute(
            "SELECT symbol, side, qty, fill_price, reason, ts_utc FROM paper_trades ORDER BY ts_utc DESC LIMIT ?",
            (int(limit),),
        )
        rows = cur.fetchall()
        rows.reverse()
        out = []
        for r in rows:
            out.append({
                "symbol": r[0],
                "side": r[1],
                "qty": float(r[2]),
                "fill_price": float(r[3]),
                "reason": r[4],
                "ts_utc": r[5],
            })
        return out
