import itertools
import pandas as pd
from core.models import IndicatorConfig
from core.indicators import compute_pack
from core.signals import classify


def _simulate(pack: pd.DataFrame) -> float:
    in_pos = False
    entry = 0.0
    pnl = 0.0

    for _, row in pack.iterrows():
        sig = classify(row)
        if not in_pos and sig["state"] == "BULLISH":
            in_pos = True
            entry = float(row["close"])
        elif in_pos and sig["state"] != "BULLISH":
            pnl += float(row["close"]) - entry
            in_pos = False

    if in_pos:
        pnl += float(pack.iloc[-1]["close"]) - entry

    return pnl


def optimize_one_year(df_ohlcv: pd.DataFrame) -> dict:
    ema_fast_grid = [8, 12, 16]
    ema_slow_grid = [21, 26, 34]
    rsi_grid = [10, 14]
    macd_signal_grid = [7, 9]

    best = {"pnl": float("-inf")}

    for ef, es, rp, ms in itertools.product(ema_fast_grid, ema_slow_grid, rsi_grid, macd_signal_grid):
        if ef >= es:
            continue
        cfg = IndicatorConfig(ema_fast=ef, ema_slow=es, rsi_period=rp, macd_signal=ms)
        pack = compute_pack(df_ohlcv, cfg).dropna()
        if len(pack) < 200:
            continue
        pnl = _simulate(pack)
        if pnl > best["pnl"]:
            best = {"pnl": pnl, "ema_fast": ef, "ema_slow": es, "rsi_period": rp, "macd_signal": ms}

    return best
