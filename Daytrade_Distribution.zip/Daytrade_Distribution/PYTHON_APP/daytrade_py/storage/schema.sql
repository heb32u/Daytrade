CREATE TABLE IF NOT EXISTS candles_5m (
  symbol TEXT NOT NULL,
  ts_utc TEXT NOT NULL,
  open REAL NOT NULL,
  high REAL NOT NULL,
  low REAL NOT NULL,
  close REAL NOT NULL,
  volume REAL NOT NULL,
  PRIMARY KEY(symbol, ts_utc)
);

CREATE TABLE IF NOT EXISTS settings_kv (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS approvals (
  approval_id TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL,
  status TEXT NOT NULL,
  created_utc TEXT NOT NULL,
  expires_utc TEXT NOT NULL,
  reason TEXT NOT NULL,
  consumed_utc TEXT
);

CREATE TABLE IF NOT EXISTS optimizer_best (
  symbol TEXT PRIMARY KEY,
  params_json TEXT NOT NULL,
  updated_utc TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS perf_stats (
  symbol TEXT PRIMARY KEY,
  wins INTEGER NOT NULL,
  losses INTEGER NOT NULL,
  pnl_real REAL NOT NULL,
  updated_utc TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS paper_positions (
  symbol TEXT PRIMARY KEY,
  qty REAL NOT NULL,
  updated_utc TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS paper_trades (
  trade_id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  side TEXT NOT NULL,
  qty REAL NOT NULL,
  fill_price REAL NOT NULL,
  reason TEXT NOT NULL,
  ts_utc TEXT NOT NULL
);
