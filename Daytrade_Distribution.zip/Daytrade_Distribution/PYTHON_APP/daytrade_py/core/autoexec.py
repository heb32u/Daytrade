from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any

from core.signals import classify
from core.sizing import atr_position_size


@dataclass
class AutoExecPolicy:
    enabled: bool = False
    min_confidence: float = 0.70
    bias_buy: float = 0.20
    bias_sell: float = -0.20
    cooldown_minutes: int = 15
    max_trades_per_day: int = 6
    max_position_abs: float = 5.0
    require_session_open: bool = True
    require_approval_per_incident: bool = True
    approval_resend_minutes: int = 5

    equity_assumed: float = 100000.0
    risk_pct: float = 0.002
    atr_stop_mult: float = 1.5
    min_qty: float = 1.0
    max_qty: float = 5.0


def utcnow():
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


class AutoExecutor:
    def __init__(self, policy: AutoExecPolicy):
        self.policy = policy
        self.last_trade_utc: Dict[str, datetime] = {}
        self.trades_today: Dict[str, int] = {}
        self.last_approval_sent_utc: Dict[str, datetime] = {}

    def can_trade_today(self) -> bool:
        d = utcnow().strftime("%Y-%m-%d")
        return self.trades_today.get(d, 0) < self.policy.max_trades_per_day

    def record_trade(self):
        d = utcnow().strftime("%Y-%m-%d")
        self.trades_today[d] = self.trades_today.get(d, 0) + 1

    def in_cooldown(self, symbol: str) -> bool:
        t = self.last_trade_utc.get(symbol.upper())
        if not t:
            return False
        return utcnow() < (t + timedelta(minutes=self.policy.cooldown_minutes))

    def mark_traded(self, symbol: str):
        self.last_trade_utc[symbol.upper()] = utcnow()
        self.record_trade()

    def should_send_approval(self, symbol: str) -> bool:
        t = self.last_approval_sent_utc.get(symbol.upper())
        if not t:
            return True
        return utcnow() >= (t + timedelta(minutes=self.policy.approval_resend_minutes))

    def mark_approval_sent(self, symbol: str):
        self.last_approval_sent_utc[symbol.upper()] = utcnow()

    def should_cancel_intent(self, pack_last_row, bias: float, session_is_open: bool) -> bool:
        if self.policy.require_session_open and not session_is_open:
            return True
        sig = classify(pack_last_row)
        if sig["confidence"] < max(0.40, self.policy.min_confidence * 0.75):
            return True
        if self.policy.bias_sell < bias < self.policy.bias_buy:
            return True
        return False

    def decide_intent(
        self,
        symbol: str,
        pack_last_row,
        bias: float,
        current_pos: float,
        session_is_open: bool,
    ) -> Optional[Dict[str, Any]]:
        if not self.policy.enabled:
            return None
        if self.policy.require_session_open and not session_is_open:
            return None
        if not self.can_trade_today():
            return None
        if self.in_cooldown(symbol):
            return None

        sig = classify(pack_last_row)
        if sig["confidence"] < self.policy.min_confidence:
            return None

        sym = symbol.upper()

        if bias >= self.policy.bias_buy and current_pos < self.policy.max_position_abs:
            side = "buy"
        elif bias <= self.policy.bias_sell and current_pos > -self.policy.max_position_abs:
            side = "sell"
        else:
            return None

        atr_val = float(pack_last_row["atr"]) if "atr" in pack_last_row else 0.0
        qty = atr_position_size(
            equity=self.policy.equity_assumed,
            risk_pct=self.policy.risk_pct,
            atr=atr_val,
            atr_mult_stop=self.policy.atr_stop_mult,
            min_qty=self.policy.min_qty,
            max_qty=self.policy.max_qty,
        )

        projected = current_pos + qty if side == "buy" else current_pos - qty
        if abs(projected) > self.policy.max_position_abs:
            return None

        reason = f"Auto paper intent: {side.upper()} {qty} {sym} | conf={sig['confidence']:.2f} bias={bias:+.2f}"
        return {"side": side, "qty": qty, "reason": reason}
