import pyqtgraph as pg
from PySide6.QtWidgets import QWidget, QVBoxLayout
from PySide6.QtGui import QColor


class ChartWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.plot = pg.PlotWidget()
        self.plot.showGrid(x=True, y=True)
        self.plot.setBackground("w")
        layout = QVBoxLayout(self)
        layout.addWidget(self.plot)

    def set_series(self, close_values):
        self.plot.clear()
        x = list(range(len(close_values)))
        self.plot.plot(x, close_values)

    def set_border_from_bias(self, bias: float, confidence: float):
        conf = max(0.0, min(1.0, float(confidence)))
        if bias > 0.15:
            base = QColor(0, 160, 0)
        elif bias < -0.15:
            base = QColor(200, 0, 0)
        else:
            base = QColor(120, 120, 120)

        r = int(base.red() * conf + 255 * (1 - conf))
        g = int(base.green() * conf + 255 * (1 - conf))
        b = int(base.blue() * conf + 255 * (1 - conf))
        self.setStyleSheet(f"border: 4px solid rgb({r},{g},{b});")
